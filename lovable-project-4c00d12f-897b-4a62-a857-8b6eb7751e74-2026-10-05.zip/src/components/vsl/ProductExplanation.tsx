import { CheckCircle2 } from "lucide-react";
import { vslConfig } from "@/config/vslConfig";
import { Reveal, SafeImage } from "./shared";

export function ProductExplanation() {
  const e = vslConfig.explanation;
  return (
    <section className="section-y bg-background-2">
      <div className="container-vsl grid items-center gap-10 md:grid-cols-2 md:gap-16">
        <Reveal className="relative">
          <div className="glow-radial absolute inset-[15%] opacity-50" aria-hidden />
          <SafeImage src={vslConfig.productImage} alt={vslConfig.productName} className="relative mx-auto h-auto w-full max-w-lg" placeholderClassName="relative aspect-square" />
        </Reveal>
        <Reveal delay={100}>
          <h2 className="text-2xl font-extrabold leading-tight sm:text-3xl md:text-4xl">{e.title}</h2>
          <p className="mt-5 text-base text-muted-foreground md:text-lg">{e.text}</p>
          <ul className="mt-7 space-y-3">
            {e.points.map((p) => (
              <li key={p} className="card-surface flex items-center gap-3 px-4 py-3.5 text-sm font-medium">
                <CheckCircle2 className="h-5 w-5 shrink-0 text-sky" aria-hidden />
                {p}
              </li>
            ))}
          </ul>
        </Reveal>
      </div>
    </section>
  );
}
