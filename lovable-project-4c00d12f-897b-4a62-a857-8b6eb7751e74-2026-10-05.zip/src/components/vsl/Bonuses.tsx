import { Gift } from "lucide-react";
import { vslConfig } from "@/config/vslConfig";
import { Reveal, SafeImage, SectionHeading } from "./shared";

export function Bonuses() {
  return (
    <section className="section-y">
      <div className="container-vsl">
        <SectionHeading eyebrow="E AINDA TEM MAIS..." title="VOCÊ TAMBÉM RECEBE MATERIAIS EXTRAS" />
        <div className="mx-auto grid max-w-2xl gap-5">
          {vslConfig.bonuses.map((b, i) => (
            <Reveal key={b.title} delay={i * 100}>
              <article className="card-surface flex h-full flex-col overflow-hidden">
                <div className="bg-background-2 p-4">
                  <SafeImage src={b.image} alt={b.title} className="mx-auto aspect-[16/10] w-full" placeholderClassName="aspect-[16/10]" />
                </div>
                <div className="flex flex-1 flex-col p-6">
                  <span className="inline-flex w-fit items-center gap-1.5 rounded-full bg-violet/20 px-3 py-1 text-[11px] font-bold tracking-wider text-sky">
                    <Gift className="h-3.5 w-3.5" aria-hidden /> BÔNUS {i + 1}
                  </span>
                  <h3 className="mt-3 font-display text-lg font-bold">{b.title}</h3>
                  <p className="mt-2 flex-1 text-sm text-muted-foreground">{b.description}</p>
                  <div className="mt-5 flex items-center gap-3">
                    {b.originalPrice && <span className="text-sm text-muted-foreground line-through">{b.originalPrice}</span>}
                    <span className="font-display text-base font-extrabold text-cta sm:text-lg">{b.currentPrice}</span>
                  </div>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
