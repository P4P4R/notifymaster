import { CheckCircle2, CreditCard, Download, ShieldCheck } from "lucide-react";
import { vslConfig } from "@/config/vslConfig";

const icons = [ShieldCheck, Download, CreditCard, CheckCircle2];

export function TrustBadges() {
  return (
    <ul className="mx-auto mt-6 grid max-w-xl grid-cols-2 gap-x-4 gap-y-2.5 text-xs text-muted-foreground sm:flex sm:max-w-none sm:flex-wrap sm:justify-center sm:gap-6 sm:text-sm">
      {vslConfig.trustBadges.map((b, i) => {
        const Icon = icons[i % icons.length] ?? ShieldCheck;
        return (
          <li key={b} className="flex items-center gap-2">
            <Icon className="h-4 w-4 shrink-0 text-cta" aria-hidden />
            {b}
          </li>
        );
      })}
    </ul>
  );
}
