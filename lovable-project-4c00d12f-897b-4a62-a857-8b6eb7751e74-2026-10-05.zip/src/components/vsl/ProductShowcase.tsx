import { Package, Eye } from "lucide-react";
import { vslConfig } from "@/config/vslConfig";
import { Reveal, SafeImage, SectionHeading } from "./shared";
import { PurchaseButton } from "./PurchaseButton";

export function ProductShowcase() {
  return (
    <section id="produtos" className="section-y">
      <div className="container-vsl">
        <SectionHeading eyebrow="CONTEÚDO" title="VEJA O QUE VOCÊ ENCONTRARÁ" />
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {vslConfig.products.map((p, i) => (
            <Reveal key={p.title} delay={i * 80}>
              <article className="card-surface group flex h-full flex-col overflow-hidden transition-transform hover:-translate-y-1">
                <div className="relative bg-background-2 p-4">
                  <span className="absolute left-3 top-3 z-10 rounded-full bg-gradient-tech px-2.5 py-1 text-[10px] font-bold tracking-wider text-primary-foreground">
                    {p.badge}
                  </span>
                  <SafeImage src={p.image} alt={p.title} className="mx-auto aspect-[4/3] w-full" placeholderClassName="aspect-[4/3]" />
                </div>
                <div className="flex flex-1 flex-col p-5">
                  <div className="flex items-center gap-2">
                    <Package className="h-4 w-4 text-sky" aria-hidden />
                    <h3 className="font-display text-base font-bold">{p.title}</h3>
                  </div>
                  <p className="mt-2 flex-1 text-sm text-muted-foreground">{p.description}</p>
                  {p.demoUrl && (
                    <a href={p.demoUrl} target="_blank" rel="noopener noreferrer" className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-sky hover:text-cyan">
                      <Eye className="h-4 w-4" aria-hidden /> Ver demonstração
                    </a>
                  )}
                </div>
              </article>
            </Reveal>
          ))}
        </div>
        <div className="mt-12 flex justify-center">
          <PurchaseButton position="products" />
        </div>
      </div>
    </section>
  );
}
