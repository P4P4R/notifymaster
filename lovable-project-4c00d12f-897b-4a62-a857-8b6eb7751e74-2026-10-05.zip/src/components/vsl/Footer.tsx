import { Link } from "@tanstack/react-router";
import { vslConfig } from "@/config/vslConfig";

export function Footer() {
  return (
    <footer id="fim-da-pagina" className="border-t border-border bg-background pb-28 pt-12 md:pb-12">
      <div className="container-vsl text-center">
        <span className="font-display text-xl font-extrabold">
          Notify<span className="text-gradient">Master</span>
        </span>
        <nav className="mt-6 flex flex-wrap justify-center gap-x-6 gap-y-2 text-sm text-muted-foreground">
          <Link to="/politica-de-privacidade" className="hover:text-foreground">Política de Privacidade</Link>
          <Link to="/termos-de-uso" className="hover:text-foreground">Termos de Uso</Link>
          {vslConfig.footer.contactUrl && (
            <a href={vslConfig.footer.contactUrl} className="hover:text-foreground">Contato</a>
          )}
        </nav>
        <p className="mt-8 text-xs text-muted-foreground">© 2026 NotifyMaster. Todos os direitos reservados.</p>
      </div>
    </footer>
  );
}
