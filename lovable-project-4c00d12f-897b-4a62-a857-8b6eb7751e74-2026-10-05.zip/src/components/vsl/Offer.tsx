import { Check, Lock } from "lucide-react";
import { vslConfig } from "@/config/vslConfig";
import { Reveal, SafeImage } from "./shared";
import { PurchaseButton } from "./PurchaseButton";

export function Offer() {
  const o = vslConfig.offer;
  return (
    <section id="oferta" className="section-y relative overflow-hidden bg-background-2">
      <div className="glow-radial pointer-events-none absolute left-1/2 top-1/3 h-[500px] w-[700px] max-w-[140vw] -translate-x-1/2 opacity-40" aria-hidden />
      <div className="container-vsl relative">
        <Reveal>
          <div className="card-glow mx-auto max-w-2xl rounded-[1.75rem] bg-card p-6 text-center sm:p-10">
            <span className="inline-block rounded-full bg-gradient-tech px-4 py-1.5 text-[11px] font-bold tracking-[0.18em] text-primary-foreground">{o.badge}</span>
            <SafeImage src={vslConfig.offerImage} alt={o.title} className="mx-auto mt-6 h-auto w-full max-w-md" placeholderClassName="mt-6 aspect-[16/10]" />
            <h2 className="mt-6 text-3xl font-black sm:text-4xl">{o.title}</h2>
            <p className="mx-auto mt-3 max-w-md text-muted-foreground">{o.text}</p>
            <ul className="mx-auto mt-7 grid max-w-md gap-3 text-left sm:grid-cols-2">
              {o.items.map((it) => (
                <li key={it} className="flex items-start gap-2.5 text-sm font-medium">
                  <Check className="mt-0.5 h-4 w-4 shrink-0 text-cta" aria-hidden />
                  {it}
                </li>
              ))}
            </ul>
            <div className="mt-8 border-t border-border pt-8">
              <p className="text-sm text-muted-foreground">
                DE <span className="line-through">{vslConfig.originalPrice}</span>
              </p>
              <p className="mt-1 font-display text-5xl font-black text-cta sm:text-6xl">{vslConfig.cashPrice}</p>
              <p className="mt-2 text-sm text-muted-foreground">OU {vslConfig.installments}</p>
            </div>
            <div className="mt-8 flex justify-center">
              <PurchaseButton position="offer" fullWidth />
            </div>
            <p className="mt-4 flex items-center justify-center gap-2 text-xs text-muted-foreground">
              <Lock className="h-3.5 w-3.5" aria-hidden /> {o.footnote}
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
