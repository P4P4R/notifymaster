// =====================================================
// NOTIFYMASTER — CONFIGURAÇÃO CENTRAL DA VSL
// Troque textos, imagens, preços e links somente aqui.
// =====================================================

export type VideoType = "youtube" | "vimeo" | "mp4" | "embed";

export const vslConfig = {
  productName: "NotifyMaster APKs",
  brandName: "NotifyMaster",

  badge: "ACESSO DIGITAL • NOTIFYMASTER APKs",
  headline: "TENHA ACESSO AO NOTIFYMASTER APKs EM UM ÚNICO LUGAR",
  highlightedWords: ["NOTIFYMASTER APKs"],
  subheadline:
    "Acesse uma coleção digital organizada de APKs acompanhada de mockups e demonstrações visuais para conhecer cada material de forma simples, rápida e profissional.",
  heroBullets: ["Conteúdo digital", "Acesso organizado", "Mockups profissionais", "Demonstrações visuais"],

  // ================================
  // IMAGENS (substitua os arquivos em /public/images)
  // ================================
  logo: "/images/logo-notifymaster.webp",
  heroImage: "/images/notifymaster-hero.webp",
  productImage: "/images/notifymaster-product.webp",
  offerImage: "/images/notifymaster-offer.webp",
  phoneImage: "/images/notifymaster-phone.webp",
  guaranteeImage: "/images/guarantee.webp",
  ogImage: "/images/og-notifymaster.webp",

  // ================================
  // VÍDEO
  // ================================
  videoUrl: "", // link do YouTube, Vimeo, .mp4 ou URL de embed
  videoType: "youtube" as VideoType,
  videoPoster: "/images/video-poster.webp",

  // ================================
  // CHECKOUT
  // ================================
  checkoutUrl: "COLOCAR_LINK_KIWIFY_AQUI",
  preserveUtms: true,

  // ================================
  // WHATSAPP
  // ================================
  whatsappEnabled: true,
  whatsappUrl:
    "https://api.whatsapp.com/send/?phone=5543988413362&text=Ol%C3%A1%2C+vim+pela+p%C3%A1gina+das+100+Receitas+de+Sobremesas+Lucrativas+e+gostaria+de+mais+informa%C3%A7%C3%B5es.&type=phone_number&app_absent=0",

  // ================================
  // PREÇOS
  // ================================
  originalPrice: "R$ XX,XX",
  cashPrice: "R$ XX,XX",
  installments: "12x de R$ XX,XX",
  productValue: 0, // valor numérico enviado aos pixels (ex: 47.9)
  currency: "BRL",

  guaranteeDays: 7,
  floatingButtonEnabled: true,

  ctaLabel: "QUERO ACESSAR O NOTIFYMASTER",

  trustBadges: ["Compra segura", "Acesso digital", "Pagamento protegido", "Liberação após confirmação"],

  explanation: {
    title: "CONHEÇA O NOTIFYMASTER APKs",
    text: "O NotifyMaster reúne os materiais digitais em um ambiente organizado para facilitar o acesso e a visualização de cada conteúdo.",
    points: ["APKs reunidos em um só produto", "Mockups para visualizar cada material", "Demonstrações para conhecer antes de usar"],
  },

  products: [
    { title: "NotifyMaster APK 01", description: "Descrição do aplicativo.", image: "/images/apk-01.webp", badge: "APK", demoUrl: "" },
    { title: "NotifyMaster APK 02", description: "Descrição do aplicativo.", image: "/images/apk-02.webp", badge: "APK", demoUrl: "" },
    { title: "NotifyMaster APK 03", description: "Descrição do aplicativo.", image: "/images/apk-03.webp", badge: "APK", demoUrl: "" },
    { title: "NotifyMaster APK 04", description: "Descrição do aplicativo.", image: "/images/apk-04.webp", badge: "APK", demoUrl: "" },
  ],

  demos: [
    "/images/demo-01.webp",
    "/images/demo-02.webp",
    "/images/demo-03.webp",
    "/images/demo-04.webp",
    "/images/demo-05.webp",
    "/images/demo-06.webp",
  ],

  phoneSection: {
    title: "TUDO ORGANIZADO PARA VOCÊ ACESSAR",
    text: "Visualize os materiais, demonstrações e informações de forma simples e organizada em qualquer dispositivo.",
    points: ["Fácil acesso", "Conteúdo organizado", "Visual moderno", "Compatível com dispositivos Android, quando aplicável ao material"],
  },

  benefits: [
    { icon: "folder", title: "TODO O MATERIAL ORGANIZADO", text: "Tenha os arquivos e conteúdos reunidos em um único produto." },
    { icon: "monitor", title: "DEMONSTRAÇÕES VISUAIS", text: "Visualize os materiais apresentados através de mockups e demonstrações." },
    { icon: "key", title: "ACESSO DIGITAL", text: "Receba as instruções de acesso após a confirmação da compra." },
    { icon: "search", title: "FÁCIL DE CONSULTAR", text: "Estrutura simples para localizar cada material." },
    { icon: "phone", title: "ACESSO PELO CELULAR", text: "Consulte as informações utilizando dispositivos compatíveis." },
    { icon: "refresh", title: "ATUALIZAÇÕES DO MATERIAL", text: "Se esta funcionalidade estiver habilitada no produto, novos materiais poderão ser disponibilizados na área correspondente." },
  ],

  before: ["Arquivos espalhados", "Dificuldade para encontrar materiais", "Falta de demonstrações", "Conteúdo sem organização", "Informações em lugares diferentes", "Visualização confusa"],
  after: ["Materiais organizados", "Demonstrações visuais", "Mockups profissionais", "Informações centralizadas", "Acesso simplificado", "Estrutura profissional"],

  // Somente depoimentos reais. Imagens ausentes mostram um espaço reservado.
  testimonials: [
    "/images/testimonial-01.webp",
    "/images/testimonial-02.webp",
    "/images/testimonial-03.webp",
  ],

  bonuses: [
    {
      title: "Mockups Premium",
      description: "Coleção complementar de apresentações visuais, disponível como adicional opcional no checkout.",
      image: "/images/bonus-mockups.webp",
      originalPrice: "",
      currentPrice: "ADICIONAL DE R$ 19,90 NO CHECKOUT",
    },
  ],

  offer: {
    badge: "ACESSO AO NOTIFYMASTER",
    title: "NotifyMaster APKs",
    text: "Tenha acesso ao pacote NotifyMaster e aos materiais apresentados nesta oferta.",
    items: ["APKs incluídos na oferta", "Mockups profissionais", "Demonstrações visuais", "Conteúdo digital organizado", "Acesso após confirmação", "Suporte conforme condições da oferta"],
    footnote: "Pagamento seguro • Liberação após confirmação",
  },

  security: [
    { title: "Pagamento protegido", text: "Seus dados de pagamento são processados pela plataforma responsável pelo checkout." },
    { title: "Acesso digital", text: "Você receberá as informações de acesso conforme as condições apresentadas na compra." },
    { title: "Ambiente seguro", text: "Utilizamos conexão segura para proteger a navegação." },
  ],

  faq: [
    { q: "O que é o NotifyMaster?", a: "O NotifyMaster APKs é um pacote digital com APKs e materiais complementares, acompanhado de mockups e demonstrações visuais para você conhecer e acessar cada conteúdo." },
    { q: "Como receberei o acesso?", a: "Após a confirmação do pagamento, você recebe as instruções de acesso no e-mail informado no checkout." },
    { q: "O produto é digital?", a: "Sim. Todo o conteúdo é digital. Nenhum material físico será enviado." },
    { q: "O que está incluído?", a: "Os APKs apresentados na oferta, mockups, demonstrações visuais e os materiais extras indicados nesta página." },
    { q: "Como funcionam os APKs?", a: "Cada material acompanha informações e demonstrações para facilitar a visualização. A compatibilidade depende de cada material e do dispositivo utilizado." },
    { q: "Posso acessar pelo celular?", a: "Sim. A área de acesso pode ser consultada pelo celular, computador ou tablet." },
    { q: "Existe garantia?", a: "Sim. A compra está sujeita às condições de garantia apresentadas no checkout." },
    { q: "Quais formas de pagamento estão disponíveis?", a: "As formas de pagamento disponíveis são exibidas no checkout da plataforma de pagamento." },
    { q: "Como funciona o suporte?", a: "O suporte é realizado pelos canais informados após a compra, conforme as condições da oferta." },
    { q: "O acesso é imediato?", a: "O acesso é liberado após a confirmação do pagamento. Pagamentos por cartão e Pix costumam ser confirmados mais rapidamente." },
  ],

  footer: {
    contactUrl:
      "https://api.whatsapp.com/send/?phone=5543988413362&text=Ol%C3%A1%2C+vim+pela+p%C3%A1gina+das+100+Receitas+de+Sobremesas+Lucrativas+e+gostaria+de+mais+informa%C3%A7%C3%B5es.&type=phone_number&app_absent=0",
  },
};
