/* eslint-disable @typescript-eslint/no-explicit-any */
import { trackingConfig } from "@/config/trackingConfig";
import { vslConfig } from "@/config/vslConfig";

declare global {
  interface Window {
    fbq?: any;
    _fbq?: any;
    gtag?: (...args: any[]) => void;
    dataLayer?: any[];
    ttq?: any;
  }
}

let initialized = false;
let gaId = "";

function addScript(src: string) {
  const s = document.createElement("script");
  s.async = true;
  s.src = src;
  document.head.appendChild(s);
}

/** Loads every configured pixel once. Missing IDs are simply skipped. */
export function initTracking(runtimeGaId?: string) {
  if (initialized || typeof window === "undefined") return;
  initialized = true;
  gaId = trackingConfig.googleAnalyticsId || runtimeGaId || "";

  window.dataLayer = window.dataLayer || [];

  if (trackingConfig.gtmId) {
    window.dataLayer.push({ "gtm.start": Date.now(), event: "gtm.js" });
    addScript(`https://www.googletagmanager.com/gtm.js?id=${trackingConfig.gtmId}`);
  }

  if (gaId) {
    addScript(`https://www.googletagmanager.com/gtag/js?id=${gaId}`);
    window.gtag = function gtag() {
      // eslint-disable-next-line prefer-rest-params
      window.dataLayer!.push(arguments);
    };
    window.gtag("set", "developer_id.dZjgwMW", true);
    window.gtag("js", new Date());
    window.gtag("config", gaId); // sends page_view
  }

  if (trackingConfig.metaPixelId) {
    const n: any = function (...args: any[]) {
      n.callMethod ? n.callMethod(...args) : n.queue.push(args);
    };
    n.push = n;
    n.loaded = true;
    n.version = "2.0";
    n.queue = [];
    window.fbq = n;
    window._fbq = n;
    addScript("https://connect.facebook.net/en_US/fbevents.js");
    window.fbq("init", trackingConfig.metaPixelId);
    window.fbq("track", "PageView");
  }

  if (trackingConfig.tiktokPixelId) {
    const ttq: any = [];
    ttq.methods = ["page", "track", "identify", "instances", "debug", "on", "off", "once", "ready", "alias", "group", "enableCookie", "disableCookie"];
    ttq.setAndDefer = (t: any, e: string) => {
      t[e] = (...args: any[]) => t.push([e, ...args]);
    };
    ttq.methods.forEach((m: string) => ttq.setAndDefer(ttq, m));
    window.ttq = ttq;
    addScript(`https://analytics.tiktok.com/i18n/pixel/events.js?sdkid=${trackingConfig.tiktokPixelId}&lib=ttq`);
    ttq.page();
  }
}

type Payload = Record<string, unknown>;

const fb = (type: "track" | "trackCustom", name: string, data?: Payload) => {
  try { window.fbq?.(type, name, data); } catch { /* noop */ }
};
const ga = (name: string, data?: Payload) => {
  try { if (gaId) window.gtag?.("event", name, data); } catch { /* noop */ }
};
const tt = (name: string, data?: Payload) => {
  try { window.ttq?.track?.(name, data); } catch { /* noop */ }
};
const gtm = (event: string, data?: Payload) => {
  try { if (trackingConfig.gtmId) window.dataLayer?.push({ event, product: vslConfig.productName, ...data }); } catch { /* noop */ }
};

const productData = () => ({
  content_name: vslConfig.productName,
  content_type: "product",
  currency: vslConfig.currency,
  value: vslConfig.productValue,
});

export const track = {
  vslViewed() {
    fb("track", "ViewContent", productData());
    fb("trackCustom", "VSLViewed");
    ga("view_item", { currency: vslConfig.currency, value: vslConfig.productValue, items: [{ item_name: vslConfig.productName }] });
    tt("ViewContent", productData());
    gtm("view_item");
  },
  scroll(percent: 25 | 50 | 75 | 90) {
    fb("trackCustom", `Scrolled${percent}`);
    ga(`scroll_${percent}`);
    gtm(`scroll_${percent}`);
  },
  section(name: "products" | "demos" | "testimonials" | "offer" | "bottom") {
    const map = {
      products: ["ReachedProducts", "view_products"],
      demos: ["ReachedDemos", "view_demos"],
      testimonials: ["ReachedTestimonials", "view_testimonials"],
      offer: ["ReachedOffer", "view_offer"],
      bottom: ["ReachedBottom", "reached_bottom"],
    } as const;
    const [meta, g] = map[name];
    fb("trackCustom", meta);
    ga(g);
    gtm(g);
  },
  checkout(position: string) {
    fb("track", "InitiateCheckout", productData());
    fb("trackCustom", "CheckoutClicked", { position });
    ga("begin_checkout", { position, currency: vslConfig.currency, value: vslConfig.productValue, items: [{ item_name: vslConfig.productName }] });
    tt("ClickButton", { ...productData(), position });
    tt("InitiateCheckout", productData());
    gtm("begin_checkout", { position });
  },
  whatsapp() {
    fb("trackCustom", "WhatsAppClicked");
    ga("whatsapp_click");
    tt("Contact");
    gtm("whatsapp_click");
  },
};
